# GA에 대한 하이퍼 하이퍼 -Opitimization

유전 알고리즘을 이용하여 XGBoost의 적정 파라미터를 자동으로 찾아내는 기법
